#ifndef Array_H
#define Array_H

void RandArray(int A[], int n, int N);

#endif