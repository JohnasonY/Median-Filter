#ifndef MedianFilter_H
#define MedianFilter_H

#include "imageio.h"
#include "RandSelection.h"

void MedianFilter(const char *infilename, int N, const char *outfilename);

#endif