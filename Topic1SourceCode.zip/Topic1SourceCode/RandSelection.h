#ifndef RandSelection_H
#define RandSelection_H

double RandSelectionTime(int A[], int i, int begin, int end);

//find the ith smallest number in the array A startring with begin index and ending with end index
int RandSelection(int A[], int i, int begin, int end);
//Randomized partition
int RandPartition(int A[], int begin, int end);

#endif
